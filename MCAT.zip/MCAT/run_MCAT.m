function results=run_MCAT(seq, res_path, bSaveImage)


close all

feature_type = 'hogcolor';
kernel_type = 'linear';
kernel.type = kernel_type;
	
features.gray = false;
features.hog = false;
features.hogcolor = false;

padding = 1.5;  %extra area surrounding the target for SAMF
paddings = 11;  %extra searching area of the target

lambda = 1e-4;  %regularization
output_sigma_factor = 0.1;  %spatial bandwidth (proportional to target)
interp_factorh = 0.04;  %context mask update rate
n_bins = 2^5;


switch feature_type
	case 'gray',
		interp_factor = 0.075;  %linear interpolation factor for adaptation

		kernel.sigma = 0.2;  %gaussian kernel bandwidth
		
		kernel.poly_a = 1;  %polynomial kernel additive term
		kernel.poly_b = 7;  %polynomial kernel exponent
	
		features.gray = true;
		cell_size = 1;
		
	case 'hog',
		interp_factor = 0.02;
		
		kernel.sigma = 0.5;
		
		kernel.poly_a = 1;
		kernel.poly_b = 9;
		
		features.hog = true;
		features.hog_orientations = 9;
		cell_size = 4;
    case 'hogcolor',
		interp_factor = 0.009;
		features.hogcolor = true;
		features.hog_orientations = 9;
		cell_size = 4;	
        kernel.sigma = 0.5;
		kernel.poly_a = 1;
		kernel.poly_b = 9;
    otherwise
    error('Unknown feature.')
end

temp = load('w2crs');
w2c = temp.w2crs;

scale_filter = false; %true = DSST;false = SAMF;
multichannel = true;   %multichannel DCF
jointly_learning = false;  %whether to use multi-task DCF
adaptive_jointly_detection = true;
show_visualization = true;
%show_visualization = false;

video_path = '';
img_files = seq.s_frames;
target_sz = [seq.init_rect(1,4), seq.init_rect(1,3)];
pos = [seq.init_rect(1,2), seq.init_rect(1,1)] + floor(target_sz/2);

%intial image resize
max_image_sample_size = 240*240;
min_image_sample_size = 160*160;
search_area = prod(target_sz)*(1+paddings);
if search_area > max_image_sample_size
    currentScaleFactor = sqrt(search_area / max_image_sample_size);
elseif search_area < min_image_sample_size
    currentScaleFactor = sqrt(search_area / min_image_sample_size);
else
    currentScaleFactor = 1.0;
end
%true_target_sz = target_sz;
target_sz0 = target_sz / currentScaleFactor; %resized target size


%window size, taking padding into account
%window_sz = floor(target_sz * (1 + padding));
%d = floor((-1*(target_sz0(1)+target_sz0(2))+sqrt((target_sz0(1)+target_sz0(2))^2+4*(paddings)*target_sz0(1)*target_sz0(2)))/2);
%window_sz = floor(target_sz0) + [d,d];
d0 = floor(sqrt((1+paddings)*target_sz0(1)*target_sz0(2))); %square search window
window_sz = [d0,d0];

y_sz = floor(window_sz / cell_size);
template_size = window_sz;
t_sz = floor(target_sz0 / cell_size);

%create regression labels, gaussian shaped, with a bandwidth
%proportional to target size
output_sigma = sqrt(prod(target_sz0)) * output_sigma_factor / cell_size;
yf = fft2(gaussian_shaped_labels(output_sigma, y_sz));

%store pre-computed cosine window
cos_window = hann(size(yf,1)) * hann(size(yf,2))';	
cos_window2 = ones(y_sz);

%SAMF
s_window_sz = floor(target_sz0*(1+padding));
s_y_sz = floor(s_window_sz / cell_size);
s_yf = fft2(gaussian_shaped_labels(output_sigma, s_y_sz));
s_cos_window = hann(s_y_sz(1)) * hann(s_y_sz(2))';

%multi-level context adaptation prediction parameters
cos_n = 3;
cos_p = [20,15,10];
cos_k = [0.5,0.26,0.24];
qp = 0.00045;
aqp = 1;
qpH = qp*diag(ones(1,3)./cos_k.^2);
zk = [0,0.4,0.8];

%multi-level context spatial window
for i=1:cos_n
    cos_a{i} = cos_p(i)*target_sz0./window_sz;
    t_window{i} = gausswin(y_sz(1),cos_a{i}(2)) * gausswin(y_sz(2),cos_a{i}(1))';
end

    
if scale_filter %DSST
    % Code from DSST
    base_target_sz = target_sz0;
    n_scales = 33;
    scale_model_factor = 1.0;
    scale_sigma_factor = 1/4;
    scale_step = 1.02;
    scale_model_max_area = 32*16;
    scale_sigma = sqrt(n_scales) * scale_sigma_factor;
    scale_lr = 0.025;
    ss = (1:n_scales) - ceil(n_scales/2);
    ys = exp(-0.5 * (ss.^2) / scale_sigma^2);
    ysf = single(fft(ys));

    if mod(n_scales,2) == 0
        scale_window = single(hann(n_scales+1));
        scale_window = scale_window(2:end);
    else
        scale_window = single(hann(n_scales));
    end

    ss = 1:n_scales;
    scaleFactors = scale_step.^(ceil(n_scales/2) - ss);

    template_size_ = template_size;
    if scale_model_factor^2 * prod(template_size_) > scale_model_max_area
        scale_model_factor = sqrt(scale_model_max_area/prod(template_size_));
    end


    scale_model_sz = floor(template_size_ * scale_model_factor);

    scaleSizeFactors = scaleFactors;
else %SAMF
    ns = 7;
    step = 1.01;
    scale_level = -floor(ns/2):1:floor(ns/2);
    scale_level = step.^scale_level;
    %scale_level = [1 0.995 1.005 0.99  1.01 0.985 1.015];
end

if show_visualization,  %create video interface
    update_visualization = show_video(img_files, video_path, 1,1/currentScaleFactor);
end

%note: variables ending with 'f' are in the Fourier domain.

time = 0;  %to calculate FPS
positions = zeros(numel(img_files), 2);  %to calculate precision

%main
for frame = 1:numel(img_files),
    %frame = frame
    %load image

    im = imread([video_path img_files{frame}]);

    %iim=im;
    %{
    if size(im,3) > 1,
        im = rgb2gray(im);
    end
    %}
    tic()

    if frame > 1,
        posold = pos;
        currentScaleFactorold = currentScaleFactor;
        %obtain a subwindow for detection at the position from last
        %frame, and convert to Fourier domain (its size is unchanged)
        [patch,mask0] = get_subwindow(im, pos, window_sz*currentScaleFactor);
        %patch = mexResize(patch, window_sz, 'auto');
        %mask = mexResize(mask0, window_sz, 'auto');
        patch = imresize(patch, window_sz);
        mask = imresize(mask0,window_sz);
        mask1 = enhancePatch(patch,model_fh,model_bh,n_bins).*mask;
        %mask1 = mexResize(mask1, y_sz, 'auto');
        mask1 = imresize(mask1,y_sz);
        z = get_features(patch, features, cell_size, cos_window.^0.4,w2c);
        z0 = bsxfun(@times, z, mask1/max(mask1(:)));

        %multi-level context detection sample
        for i=1:cos_n
            z1 = z*zk(i)+z0*(1-zk(i));
            z1f{i} = fft2(z1);
        end

        for i=1:cos_n
            if ~multichannel
                fresponse1(:,:,i) = sum(conj(model_H{i}).*z1f{i},3);
            else
                fresponse1(:,:,i) = bsxfun(@rdivide, sum(conj(model_A{i}).*z1f{i},3), model_B{i} + lambda);
            end
            r{i} = real(ifft2(fresponse1(:,:,i)));
            ap(1,i) = calAPCE(r{i});
        end

        %Adaptive multi-level prediction fusing
        if frame>2 && adaptive_jointly_detection
            qpf = aqp*ones(1,3)./(ap.^2);
            options.Display = 'off';
            qpmin = [0;0;0];
            qpk = quadprog(qpH,qpf,[],[],ones(1,3),1,qpmin,[],[],options);
        else
            qpk = cos_k';
        end

        response = r{1}*qpk(1);
        for i=2:cos_n
            response = response + r{i}*qpk(i);
        end

        %{
        if ~show_visualization %debugging 
            sk = response;
            rkx = circshift(sk, floor(y_sz(1:2) / 2) - 1);
            sk = real(ifft2(fresponse1(:,:,1)));
            rkx1 = circshift(sk, floor(y_sz(1:2) / 2) - 1);
            sk = real(ifft2(fresponse1(:,:,2)));
            rkx2 = circshift(sk, floor(y_sz(1:2) / 2) - 1);
            sk = real(ifft2(fresponse1(:,:,3)));
            rkx3 = circshift(sk, floor(y_sz(1:2) / 2) - 1);
            subplot(321);imshow(patch);
            subplot(323);mesh(rkx);
            subplot(322);mesh(rkx1);
            subplot(324);mesh(rkx2);
            subplot(326);mesh(rkx3);
            pause(0.01);
            if frame == 156
                %return;
            end
        end
        %}

        [vert_delta, horiz_delta] = find(response == max(response(:)), 1);
        if vert_delta > y_sz(1) / 2,  %wrap around to negative half-space of vertical axis
            vert_delta = vert_delta - y_sz(1);
        end
        if horiz_delta > y_sz(2) / 2,  %same for horizontal axis
            horiz_delta = horiz_delta - y_sz(2);
        end
        pos = pos + cell_size * [vert_delta - 1, horiz_delta - 1]*currentScaleFactor;

        APCE = calAPCE(response);%tracking result evaluation

        if APCE<avg_APCE*0.13 %keep stationary
            pos = posold;
            currentScaleFactor = currentScaleFactorold;
        elseif APCE>avg_APCE*0.2 && APCE>10 %scale updation
        %do a scale space search aswell
            if scale_filter %DSST, scale adjustment only
                xs = get_scale_subwindow(im, pos, base_target_sz, ...
                    currentScaleFactor * scaleSizeFactors, ...
                    scale_window, scale_model_sz([2,1]), []);
                xsf = fft(xs,[],2);
                % scale correlation response
                scale_response = real(ifft(sum(sf_num .* xsf, 1) ./ (sf_den + 1e-2) ));
                recovered_scale = ind2sub(size(scale_response),find(scale_response == max(scale_response(:)), 1));
                %set the scale
                currentScaleFactor = currentScaleFactor * (scaleFactors(recovered_scale));

                % check for min/max scale
                if currentScaleFactor < min_scale_factor
                    currentScaleFactor = min_scale_factor;
                elseif currentScaleFactor > max_scale_factor
                    currentScaleFactor = max_scale_factor;
                end
            else %SAMF, scale and translation adjustment
                for i = 1:ns
                    patch = get_subwindow(im, pos, s_window_sz*currentScaleFactor*scale_level(i));
                    %patch = mexResize(patch, s_window_sz, 'auto');
                    patch = imresize(patch, s_window_sz);
                    z = get_features(patch, features, cell_size, s_cos_window,w2c);
                    zf = fft2(z);
                    kzf = kernel_correlation(zf,model_xf,kernel);
                    responsei = real(ifft2(kzf.*model_alphaf));
                    rm = max(responsei(:));
                    if i == 1 || rm>rt
                        rt = rm;
                        response = responsei;
                        si = i;
                    end
                end
                currentScaleFactor = currentScaleFactor*scale_level(si);

                [vert_delta, horiz_delta] = find(response == max(response(:)), 1);
                if vert_delta > s_y_sz(1) / 2,  %wrap around to negative half-space of vertical axis
                    vert_delta = vert_delta - s_y_sz(1);
                end
                if horiz_delta > s_y_sz(2) / 2,  %same for horizontal axis
                    horiz_delta = horiz_delta - s_y_sz(2);
                end
                pos = pos + cell_size * [vert_delta - 1, horiz_delta - 1]*currentScaleFactor;

            end

            target_sz = target_sz0*currentScaleFactor;
        end
    end
    
    %model update
    if mod(frame,1) == 0 && (frame<5 || (APCE > avg_APCE * 0.2))
        if frame == 1
            avg_APCE = 0;
        else
            if frame ==2
                avg_APCE = APCE;
            else
                avg_APCE = (avg_APCE*(frame-2) + APCE)/(frame-1);
            end
        end

        %obtain a subwindow for training at newly estimated target position
        [patch,mask0] = get_subwindow(im, pos, window_sz*currentScaleFactor);
        %patch = mexResize(patch, window_sz, 'auto');
        %mask0 = mexResize(mask0, window_sz, 'auto');
        patch = imresize(patch, window_sz);
        mask0 = imresize(mask0,window_sz);
        % DAT learning
        [fg_hist_new,bg_hist_new] = gethist(patch,target_sz0,mask0,n_bins);

        x = get_features(patch, features, cell_size, cos_window2,w2c);

        for i =1:cos_n
            x0{i} = bsxfun(@times, x, t_window{i});
            x0f{i} = fft2(x0{i});
        end
        
        %multi-task DCF
        [H,A,B] = getfilter(x0f,yf,cos_k,jointly_learning);
        
        if frame == 1,  %first frame, train with a single image
            model_H = H;
            model_A = A;
            model_B = B;
            model_fh = fg_hist_new;
            model_bh = bg_hist_new;
        else
            %subsequent frames, interpolate model
            for i =1:cos_n
                model_H{i} = (1 - interp_factor) * model_H{i} + interp_factor * H{i};
                model_A{i} = (1 - interp_factor) * model_A{i} + interp_factor * A{i};
                model_B{i} = (1 - interp_factor) * model_B{i} + interp_factor * B{i};
            end
            model_fh = (1 - interp_factorh) * model_fh + interp_factorh * fg_hist_new;
            model_bh = (1 - interp_factorh) * model_bh + interp_factorh * bg_hist_new;
        end
        if scale_filter
            if frame == 1
                min_scale_factor = scale_step ^ ceil(log(max(5 ./ template_size_)) / log(scale_step));
                max_scale_factor = scale_step ^ floor(log(min([size(im,1) size(im,2)] ./ base_target_sz)) / log(scale_step));
            end
            xs = get_scale_subwindow(im, pos, base_target_sz, ...
            currentScaleFactor * scaleSizeFactors, scale_window, scale_model_sz([2,1]), []);
            % fft over the scale dim
            xsf = fft(xs,[],2);
            new_sf_num = bsxfun(@times, ysf, conj(xsf));
            new_sf_den = sum(xsf .* conj(xsf), 1);
            % auto-regressive scale filters update
            if frame == 1
                sf_den = new_sf_den;
                sf_num = new_sf_num;
            else
                slr = scale_lr;
                sf_den = (1 - slr) * sf_den + slr * new_sf_den;
                sf_num = (1 - slr) * sf_num + slr * new_sf_num;
            end
        else
            s_patch = get_subwindow(im, pos, s_window_sz*currentScaleFactor);
            %s_patch = mexResize(s_patch, s_window_sz, 'auto');
            s_patch = imresize(s_patch,s_window_sz);
            s_x = get_features(s_patch, features, cell_size, s_cos_window,w2c);
            s_xf = fft2(s_x);
            kf = kernel_correlation(s_xf,s_xf,kernel);
            s_alphaf =s_yf ./ (kf + lambda);
            if frame == 1,  %first frame, train with a single image
                model_xf = s_xf;
                model_alphaf = s_alphaf;
            else
                model_alphaf = (1 - interp_factor) * model_alphaf + interp_factor * s_alphaf;
                model_xf = (1 - interp_factor) * model_xf + interp_factor * s_xf;
            end
        end
    end

    %save position and timing
    positions(frame,:) = pos;
    rect = [pos-floor(target_sz/2),target_sz];
    rect = [rect(2),rect(1),rect(4),rect(3)];
    res(frame,:) = rect;
    time = time + toc();

    %visualization
    if show_visualization,
        box = [pos([2,1]) - target_sz([2,1])/2, target_sz([2,1])];
        stop = update_visualization(frame, box);
        if stop, break, end  %user pressed Esc, stop early

        drawnow
        %pause(0.05)  %uncomment to run slower
    end

end


fps = numel(img_files) / time;

disp(['fps: ' num2str(fps)])

results.type = 'rect';
results.res = res;%each row is a rectangle
results.fps = fps;
end
%show the precisions plot
% show_precision(positions, ground_truth, video_path)

function kf = kernel_correlation(xf,yf,kernel)
    switch kernel.type
    case 'gaussian',
        kf = gaussian_correlation(xf, yf, kernel.sigma);
    case 'polynomial',
        kf = polynomial_correlation(xf, yf, kernel.poly_a, kernel.poly_b);
    case 'linear',
        kf = linear_correlation(xf, yf);
    end
end

function a = calAPCE(r)
y_sz = size(r);
f_max = max(r(:));
f_min = min(r(:));
a = (f_max - f_min)^2*y_sz(1)*y_sz(2)/sum((r(:)-f_min).^2);
a = double(a);
end