function MCAT
cleanup = onCleanup(@() exit() );

RandStream.setGlobalStream(RandStream('mt19937ar', 'Seed', sum(clock)));

[handle, image, region] = vot('rectangle');

[state, ~] = initialize(imread(image), region);

while true
    [handle, image] = handle.frame(handle);
    if isempty(image)
        break;
    end;   
    [state, region] = update(state, imread(image));  
    handle = handle.report(handle, region);  
end;

handle.quit(handle);

end

function [state, location] = initialize(I, region, varargin)
    state.frame = 1;
    if numel(region) > 4
        x1 = round(min(region(1:2:end)));
        x2 = round(max(region(1:2:end)));
        y1 = round(min(region(2:2:end)));
        y2 = round(max(region(2:2:end)));
        region = round([x1, y1, x2 - x1, y2 - y1]);
    else
        region = round([round(region(1)), round(region(2)), ... 
            round(region(1) + region(3)) - round(region(1)), ...
            round(region(2) + region(4)) - round(region(2))]);
    end;

    state.show_visualization = true;
    
    state.scale_filter = true; %true = DSST;false = SAMF;
    state.multichannel = true;   %multichannel DCF
    state.jointly_learning = false;  %whether to use multi-task DCF
    state.adaptive_jointly_detection = false;

    init_rect = region;

    padding = 1.5;  %extra area surrounding the target for SAMF
    paddings = 11;  %extra searching area of the target

    state.lambda = 1e-4;  %regularization
    output_sigma_factor = 0.1;  %spatial bandwidth (proportional to target)
    
    kernel_type = 'linear';
    kernel.type = kernel_type;
    kernel.sigma = 0.5;
    kernel.poly_a = 1;
    kernel.poly_b = 9;
    state.kernel = kernel;
    
    features.gray = false;
    features.hog = false;
    features.hogcolor = true;
    features.hog_orientations = 9;
    state.features = features;
    state.interp_factor = 0.009;
    state.cell_size = 4;	

    temp = load('w2crs');
    state.w2c = temp.w2crs;
    state.interp_factorh = 0.04;  %context mask update rate
    state.n_bins = 2^5;

    target_sz = [init_rect(1,4), init_rect(1,3)];
    state.target_sz = target_sz;
    pos = [init_rect(1,2), init_rect(1,1)] + floor(target_sz/2);
    state.pos = pos;
    max_image_sample_size = 240*240;
    min_image_sample_size = 160*160;
    search_area = prod(target_sz)*(1+paddings);
    if search_area > max_image_sample_size
        currentScaleFactor = sqrt(search_area / max_image_sample_size);
    elseif search_area < min_image_sample_size
        currentScaleFactor = sqrt(search_area / min_image_sample_size);
    else
        currentScaleFactor = 1.0;
    end
    %true_target_sz = target_sz;
    target_sz0 = target_sz / currentScaleFactor;%resized target size
    state.target_sz0 = target_sz0;
    state.currentScaleFactor = currentScaleFactor;
    
    d0 = floor(sqrt((1+paddings)*target_sz0(1)*target_sz0(2))); %square search window
    window_sz = [d0,d0];
    state.window_sz = window_sz;
    y_sz = floor(window_sz / state.cell_size);
    state.y_sz = y_sz;

    output_sigma = sqrt(prod(target_sz0)) * output_sigma_factor / state.cell_size;
    state.yf = fft2(gaussian_shaped_labels(output_sigma, y_sz));

    %store pre-computed cosine window
    state.cos_window = hann(y_sz(1)) * hann(y_sz(2))';	
    state.cos_window2 = ones(y_sz);
    
    %SAMF
    state.s_window_sz = floor(target_sz0*(1+padding));
    state.s_y_sz = floor(state.s_window_sz / state.cell_size);
    state.s_yf = fft2(gaussian_shaped_labels(output_sigma, state.s_y_sz));
    state.s_cos_window = hann(state.s_y_sz(1)) * hann(state.s_y_sz(2))';

    %multi-level context adaptation prediction parameters
    state.cos_n = 3;
    cos_p = [20,15,10];
    %state.cos_k = [0.5,0.26,0.24];
    state.cos_k = [0.5,0.26,0.24];
    state.qp = 0.00045;
    state.aqp = 1;
    state.qpH = state.qp*diag(ones(1,3)./state.cos_k.^2);
    state.zk = [0,0.4,0.8];
    %
    %multi-level context spatial window
    for i=1:state.cos_n
        state.cos_a{i} = cos_p(i)*target_sz0./window_sz;
        state.t_window{i} = gausswin(y_sz(1),state.cos_a{i}(2)) * gausswin(y_sz(2),state.cos_a{i}(1))';
    end
    
    if state.scale_filter %DSST
        % Code from DSST
        base_target_sz = target_sz0;
        state.base_target_sz = base_target_sz;
        n_scales = 33;
        scale_model_factor = 1.0;
        scale_sigma_factor = 1/4;
        scale_step = 1.02;
        scale_model_max_area = 32*16;
        scale_sigma = sqrt(n_scales) * scale_sigma_factor;
        state.scale_lr = 0.025;
        ss = (1:n_scales) - ceil(n_scales/2);
        ys = exp(-0.5 * (ss.^2) / scale_sigma^2);
        state.ysf = single(fft(ys));

        if mod(n_scales,2) == 0
            scale_window = single(hann(n_scales+1));
            state.scale_window = scale_window(2:end);
        else
            state.scale_window = single(hann(n_scales));
        end

        ss = 1:n_scales;
        scaleFactors = scale_step.^(ceil(n_scales/2) - ss);

        template_size_ = window_sz;
        if scale_model_factor^2 * prod(template_size_) > scale_model_max_area
            scale_model_factor = sqrt(scale_model_max_area/prod(template_size_));
        end


        state.scale_model_sz = floor(template_size_ * scale_model_factor);

        state.scaleSizeFactors = scaleFactors;
        state.scaleFactors = scaleFactors;
    else
        ns = 7;
        state.ns = ns;
        step = 1.01;
        scale_level = -floor(ns/2):1:floor(ns/2);
        state.scale_level = step.^scale_level;
        %scale_level = [1 0.995 1.005 0.99  1.01 0.985 1.015];
    end
    state.avg_APCE = 0;
    %
    [patch,mask0] = get_subwindow(I, pos, window_sz*currentScaleFactor);
    patch = imresize(patch, window_sz);
    mask0 = imresize(mask0,window_sz);

    % DAT learning
    [fg_hist_new,bg_hist_new] = gethist(patch,target_sz0,mask0,state.n_bins);

    x = get_features(patch, state.features, state.cell_size, state.cos_window2,state.w2c);
    %
    for i =1:state.cos_n
        x0{i} = bsxfun(@times, x, state.t_window{i});
        x0f{i} = fft2(x0{i});
    end
    %
    [H,A,B] = getfilter(x0f,state.yf,state.cos_k,state.jointly_learning);
    %
    state.model_H = H;
    state.model_A = A;
    state.model_B = B;
    state.model_fh = fg_hist_new;
    state.model_bh = bg_hist_new;
%
    if state.scale_filter
        state.min_scale_factor = scale_step ^ ceil(log(max(5 ./ template_size_)) / log(scale_step));
        state.max_scale_factor = scale_step ^ floor(log(min([size(I,1) size(I,2)] ./ state.base_target_sz)) / log(scale_step));

        xs = get_scale_subwindow(I, state.pos, state.base_target_sz, ...
        state.currentScaleFactor * state.scaleSizeFactors, state.scale_window, state.scale_model_sz([2,1]), []);
        % fft over the scale dim
        xsf = fft(xs,[],2);
        new_sf_num = bsxfun(@times, state.ysf, conj(xsf));
        new_sf_den = sum(xsf .* conj(xsf), 1);
        % auto-regressive scale filters update
        state.sf_den = new_sf_den;
        state.sf_num = new_sf_num;
    else
        s_patch = get_subwindow(I, pos, state.s_window_sz*currentScaleFactor);
        s_patch = imresize(s_patch,state.s_window_sz);
        s_x = get_features(s_patch, state.features, state.cell_size, state.s_cos_window,state.w2c);
        s_xf = fft2(s_x);
        %
        kf = kernel_correlation(s_xf,s_xf,state.kernel);
        s_alphaf =state.s_yf ./ (kf + state.lambda);

        state.model_xf = s_xf;
        state.model_alphaf = s_alphaf;
    end
%}
    location = region;
    state.location = location;
    if state.show_visualization,  %create video interface
        imshow(I);hold on;
        rectangle('Position',[location(1),location(2),location(3),location(4)],...
                             'Linewidth',2,'LineStyle','-','edgecolor','r');
        hold off;
        drawnow
        %pause(0.1);
    end
end

function [state, location] = update(state, I, varargin)
    state.frame = state.frame+1;
    %
    posold = state.pos;
    currentScaleFactorold = state.currentScaleFactor;
    window_sz = state.window_sz;
    y_sz = state.y_sz;
    [patch,mask0] = get_subwindow(I, state.pos, window_sz*state.currentScaleFactor);
    patch = imresize(patch, window_sz);
    mask = imresize(mask0,window_sz);
    mask1 = enhancePatch(patch,state.model_fh,state.model_bh,state.n_bins).*mask;
    mask1 = imresize(mask1,y_sz);
    %
    z = get_features(patch, state.features, state.cell_size, state.cos_window.^1,state.w2c);
    z0 = bsxfun(@times, z, mask1/max(mask1(:)));
    for i=1:state.cos_n
                z1 = z*state.zk(i)+z0*(1-state.zk(i));
                z1f{i} = fft2(z1);
    end
    
    for i=1:state.cos_n
        if ~state.multichannel
            fresponse1(:,:,i) = sum(conj(state.model_H{i}).*z1f{i},3);
        else
            fresponse1(:,:,i) = bsxfun(@rdivide, sum(conj(state.model_A{i}).*z1f{i},3), state.model_B{i} + state.lambda);
        end
        r{i} = real(ifft2(fresponse1(:,:,i)));
        ap(1,i) = calAPCE(r{i});
    end
%
    if  state.adaptive_jointly_detection
        qpf = state.aqp*ones(1,3)./(ap.^2);
        options.Display = 'off';
        qpmin = [0;0;0];
        qpk = quadprog(state.qpH,qpf,[],[],ones(1,3),1,qpmin,[],[],options);
    else
        qpk = state.cos_k';
    end
    response = r{1}*qpk(1);
    for i=2:state.cos_n
        response = response + r{i}*qpk(i);
    end
    [vert_delta, horiz_delta] = find(response == max(response(:)), 1);
    if vert_delta > y_sz(1) / 2,  %wrap around to negative half-space of vertical axis
        vert_delta = vert_delta - y_sz(1);
    end
    if horiz_delta > y_sz(2) / 2,  %same for horizontal axis
        horiz_delta = horiz_delta - y_sz(2);
    end
    state.pos = state.pos + state.cell_size * [vert_delta - 1, horiz_delta - 1]*state.currentScaleFactor;

    APCE = calAPCE(response);%tracking result evaluation
%
    if APCE<state.avg_APCE*0.05 %keep stationary
        state.pos = posold;
        state.currentScaleFactor = currentScaleFactorold;
    elseif 1%APCE>state.avg_APCE*0.2 && APCE>10 %scale updation
        %
        if state.scale_filter %DSST, scale adjustment only
            xs = get_scale_subwindow(I, state.pos, state.base_target_sz, ...
                state.currentScaleFactor * state.scaleSizeFactors, ...
                state.scale_window, state.scale_model_sz([2,1]), []);
            xsf = fft(xs,[],2);
            % scale correlation response
            scale_response = real(ifft(sum(state.sf_num .* xsf, 1) ./ (state.sf_den + 1e-2) ));
            recovered_scale = ind2sub(size(scale_response),find(scale_response == max(scale_response(:)), 1));
            %set the scale
            state.currentScaleFactor = state.currentScaleFactor * (state.scaleFactors(recovered_scale));

            % check for min/max scale
            if state.currentScaleFactor < state.min_scale_factor
                state.currentScaleFactor = state.min_scale_factor;
            elseif state.currentScaleFactor > state.max_scale_factor
                state.currentScaleFactor = state.max_scale_factor;
            end
        else %SAMF, scale and translation adjustment
            for i = 1:state.ns
                patch = get_subwindow(I, state.pos, state.s_window_sz*state.currentScaleFactor*state.scale_level(i));
                %patch = mexResize(patch, s_window_sz, 'auto');
                patch = imresize(patch, state.s_window_sz);
                z = get_features(patch, state.features, state.cell_size, state.s_cos_window,state.w2c);
                zf = fft2(z);
                kzf = kernel_correlation(zf,state.model_xf,state.kernel);
                responsei = real(ifft2(kzf.*state.model_alphaf));
                rm = max(responsei(:));
                if i == 1 || rm>rt
                    rt = rm;
                    response = responsei;
                    si = i;
                end
            end
            %
            state.currentScaleFactor = state.currentScaleFactor*state.scale_level(si);

            [vert_delta, horiz_delta] = find(response == max(response(:)), 1);
            if vert_delta > state.s_y_sz(1) / 2,  %wrap around to negative half-space of vertical axis
                vert_delta = vert_delta - state.s_y_sz(1);
            end
            if horiz_delta > state.s_y_sz(2) / 2,  %same for horizontal axis
                horiz_delta = horiz_delta - state.s_y_sz(2);
            end
            state.pos = state.pos + state.cell_size * [vert_delta - 1, horiz_delta - 1]*state.currentScaleFactor;
        end
        %}
    end
    
    target_sz = state.target_sz0*state.currentScaleFactor;
    rect = [state.pos-floor(target_sz/2),target_sz];
    location = [rect(2),rect(1),rect(4),rect(3)];
    
    %location = state.location;
    if  state.show_visualization,
        imshow(I);hold on;title(state.frame);
        rectangle('Position',[location(1),location(2),location(3),location(4)],...
                             'Linewidth',2,'LineStyle','-','edgecolor','r');
        hold off;
        drawnow
        %pause(0.1);
    end
    %
    %if state.frame<5 || (APCE > state.avg_APCE * 0.2)
    if mod(state.frame,1) == 0 
            if state.frame ==2
                state.avg_APCE = APCE;
            else
                state.avg_APCE = (state.avg_APCE*(state.frame-2) + APCE)/(state.frame-1);
            end
            [patch,mask0] = get_subwindow(I, state.pos, window_sz*state.currentScaleFactor);
            patch = imresize(patch, window_sz);
            mask0 = imresize(mask0,window_sz);
            % DAT learning
            [fg_hist_new,bg_hist_new] = gethist(patch,state.target_sz0,mask0,state.n_bins);

            x = get_features(patch, state.features, state.cell_size, state.cos_window2,state.w2c);

            for i =1:state.cos_n
                x0{i} = bsxfun(@times, x, state.t_window{i});
                x0f{i} = fft2(x0{i});
            end
%
            [H,A,B] = getfilter(x0f,state.yf,state.cos_k,state.jointly_learning);
            for i =1:state.cos_n
                state.model_H{i} = (1 - state.interp_factor) * state.model_H{i} + state.interp_factor * H{i};
                state.model_A{i} = (1 - state.interp_factor) * state.model_A{i} + state.interp_factor * A{i};
                state.model_B{i} = (1 - state.interp_factor) * state.model_B{i} + state.interp_factor * B{i};
            end
            %
            state.model_fh = (1 - state.interp_factorh) * state.model_fh + state.interp_factorh * fg_hist_new;
            state.model_bh = (1 - state.interp_factorh) * state.model_bh + state.interp_factorh * bg_hist_new;
            
            if state.scale_filter
                xs = get_scale_subwindow(I, state.pos, state.base_target_sz, ...
                state.currentScaleFactor * state.scaleSizeFactors, state.scale_window, state.scale_model_sz([2,1]), []);
                % fft over the scale dim
                xsf = fft(xs,[],2);
                new_sf_num = bsxfun(@times, state.ysf, conj(xsf));
                new_sf_den = sum(xsf .* conj(xsf), 1);
                % auto-regressive scale filters update
                slr = state.scale_lr;
                state.sf_den = (1 - slr) * state.sf_den + slr * new_sf_den;
                state.sf_num = (1 - slr) * state.sf_num + slr * new_sf_num;
            else
            
                s_patch = get_subwindow(I, state.pos, state.s_window_sz*state.currentScaleFactor);
                %s_patch = mexResize(s_patch, s_window_sz, 'auto');

                s_patch = imresize(s_patch,state.s_window_sz);
                s_x = get_features(s_patch, state.features, state.cell_size, state.s_cos_window,state.w2c);
                %
                s_xf = fft2(s_x);
                kf = kernel_correlation(s_xf,s_xf,state.kernel);
                s_alphaf =state.s_yf ./ (kf + state.lambda);
                %
                state.model_alphaf = (1 - state.interp_factor) * state.model_alphaf + state.interp_factor * s_alphaf;
                state.model_xf = (1 - state.interp_factor) * state.model_xf + state.interp_factor * s_xf;
            end
    end
    %}
    
end

function kf = kernel_correlation(xf,yf,kernel)
    switch kernel.type
    case 'gaussian',
        kf = gaussian_correlation(xf, yf, kernel.sigma);
    case 'polynomial',
        kf = polynomial_correlation(xf, yf, kernel.poly_a, kernel.poly_b);
    case 'linear',
        kf = linear_correlation(xf, yf);
    end
end

function a = calAPCE(r)
y_sz = size(r);
f_max = max(r(:));
f_min = min(r(:));
a = (f_max - f_min)^2*y_sz(1)*y_sz(2)/sum((r(:)-f_min).^2);
a = double(a);
end