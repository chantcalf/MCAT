function [fg_hist_new,bg_hist_new] = gethist(patch,t_sz,mask,n_bins)
[n,m,k] = size(patch);
t_mask = zeros(n,m);
s = floor(([n,m]-t_sz)/2);
t_sz = floor(t_sz);
t_mask(s(1)+1:s(1)+t_sz(1),s(2)+1:s(2)+t_sz(2)) = 1;
b_mask = 1 - t_mask;
%{
b_mask(1:d,:) = 0;
b_mask(n-d+1:n,:) = 0;
b_mask(:,1:d) = 0;
b_mask(:,m-d+1:m) = 0;
%}
t_mask = zeros(n,m);
t_sz1 = floor(t_sz*0.8);
s = floor(([n,m]-t_sz1)/2);
t_mask(s(1)+1:s(1)+t_sz1(1),s(2)+1:s(2)+t_sz1(2)) = 1;

%subplot(121);imshow(t_mask);
%subplot(122);imshow(b_mask);
%return;

if k>1
    k=0;
end
fg_hist_new = computeHistogram(patch, t_mask.*mask, n_bins, k);
bg_hist_new = computeHistogram(patch, b_mask.*mask, n_bins, k);

