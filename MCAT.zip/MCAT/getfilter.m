function [H,A,B] = getfilter(f,g,k,multitask)
lambda = 1e-4;
lambda1 = 1e-3;
mu = 1e-1;
beta =  3;
mu_max = 2;
max_iters = 4;
n = size(f,2);
d = size(f,3);

for i = 1:n
    Sxy{i} = bsxfun(@times, f{i}, conj(g));
    Sxx{i} = f{i}.*conj(f{i});
    A{i} = Sxy{i};
    B0{i} = sum(Sxx{i},3); 
    for j=1:d
        B1{i}(:,:,j) = B0{i};
    end
    %B{i} = Sxx{i};
    H{i} = bsxfun(@rdivide, Sxy{i}, (Sxx{i} + lambda));
    L{i} = zeros(size(H{i}));
    v{i} = zeros(size(H{i}));
end
B = B0;
if multitask
    iter = 1;
    while true
        for i = 1:n
            if i==1
                Hc = (H{i}-v{i}+L{i}/mu)*k(i);
            else
                Hc = Hc + (H{i}-v{i}+L{i}/mu)*k(i);
            end
        end

        for i = 1:n
            xx = H{i}-Hc+L{i}/mu;
            v{i} = abs(xx)-lambda1/mu;
            v{i}(v{i}<0) = 0;
            v{i} = v{i}.*sign(xx);
        end

        for i = 1:n
            C = mu/2*(Hc+v{i})-L{i}/2;
            Cf = fft2(C);
            A{i} = Sxy{i}+conj(Cf);
            B{i} = B1{i}+mu/2+lambda;
            Hf = A{i}./B{i};
            H{i} = ifft2(Hf);
        end


        % stop optimization after fixed number of steps
        if iter >= max_iters
            break;
        end

        % update variables for next iteration
        for i = 1:n
            L{i} = L{i}+mu*(H{i}-Hc-v{i});
        end
        mu = min(mu_max, beta*mu);
        iter = iter + 1;
    end
end
for i = 1:n
    H{i} = fft2(H{i});
end
