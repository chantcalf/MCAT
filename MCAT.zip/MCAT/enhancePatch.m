function mask = enhancePatch(patch,fh,bh,n_bins)
[n,m,k] = size(patch);
%{
p = fh./(fh+bh+eps);
p(fh+bh==0) = 0.5;
bin_width = 256/n_bins;
bin_indices = floor(double(patch)/bin_width) + 1;
for i=1:n
    for j=1:m
        mask(i,j) = p(bin_indices(i,j));
    end
end
%}
if k>1
    k=0;
end
mask = getColourMap(patch, bh, fh, n_bins, k);
% (TODO) in theory it should be at 0.5 (unseen colors shoud have max entropy)
mask(isnan(mask)) = 0.5;

%{
figure(1)
subplot(121);imshow(patch);
subplot(122);imshow(mask);
%}